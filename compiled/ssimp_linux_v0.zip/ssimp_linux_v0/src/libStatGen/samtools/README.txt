These files are based on samtools version 981. (retrieved 7/26/11)
