#ifndef assert
	#include <cassert>
#endif
