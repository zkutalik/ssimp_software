namespace logging {
void setup_the_console_logging() ;
} //namespace logging
